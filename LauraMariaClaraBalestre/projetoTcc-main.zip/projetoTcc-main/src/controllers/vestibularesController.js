class VestibularesController{
    static async getVestibulares(req, res){
        res.render('vestibulares');
    }
}

module.exports = VestibularesController;