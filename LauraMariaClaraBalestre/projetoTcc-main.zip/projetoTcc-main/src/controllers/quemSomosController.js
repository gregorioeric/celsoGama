module.exports = class QuemsomosController {
  static async getQuemsomos(req, res) {
    return res.render("quemSomos");
  }
};
