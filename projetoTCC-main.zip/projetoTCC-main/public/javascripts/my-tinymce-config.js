tinymce.init({
  selector: "textarea#my-expressjs-tinymce-app",
  plugins: "lists link image table code wordcount media",
  resize: false,
  relative_urls: false,
  license_key: "gvy2y97uhkbaedj79tvuzliezokxtozg80rva1llchwkmy3b",
  toolbar:
    "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat",
});
