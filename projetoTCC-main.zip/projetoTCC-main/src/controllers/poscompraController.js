module.exports =  class poscompraController {
    static async getposcompra(req, res){
        res.render('poscompra');
    }
}
