module.exports =  class ContatoController {
    static async getcontato(req, res){
        res.render('contato');
    }
}
