module.exports =  class compraController {
    static async getcompra(req, res){
        res.render('compra');
    }
}