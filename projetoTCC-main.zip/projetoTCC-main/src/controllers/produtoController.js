class ProdutoController {
    static async getproduto(req, res){
        res.render('produto');
    }
}

module.exports = ProdutoController;