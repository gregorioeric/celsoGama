module.exports = class fichaController {
  static async getficha(req, res) {
    return res.render("ficha");
  }
};
