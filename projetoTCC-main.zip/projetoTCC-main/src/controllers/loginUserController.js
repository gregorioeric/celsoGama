class LoginUsesrControllers {
  loginGet() {
    console.log("Login Page");
  }
}

module.exports = LoginUsesrControllers;
